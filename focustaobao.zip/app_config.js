var app_config = {
    nodejs_runtime:{
        uid: 502,
        gid: 20
    },
    mongodb_config: {
        uri: 'mongodb://localhost/focustaobao'
    },

    mongodb_login_info: {
        user: 'root',
        pwd: ''
    },

    session_config: {
        cookie_secret: 'XhatkhkbmnvRUtvxt677jmZbxre012MVDqss71',
        mongo_uri: 'mongodb://localhost/sessions'
    },

    cookie_config: {
        maxAge: 10 * 60 * 1000
    },

    taobao_api: {
        app_key: "21769413",
        app_secret: "d8c1e2aaf8eea8a7729f8a29d51dffad"
    }
}

module.exports = app_config;