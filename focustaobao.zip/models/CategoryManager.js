var MemManager = require("../datas/MemManager"),
    async = require("async"),
    Category = require("../models/Category"),
    Cat = Category.model,
    taobao = require("taobao");

module.exports = exports = (function () {
    this.mem = MemManager.getMem("catmanager");
    var that = this;

    (function () {
        async.waterfall([
            function (cb) {
                Category.queryAllCats(function (err, data) {
                    console.log("queryAllCats");
                    cb(err, data);
                })
            },

            function (data, cb) {
                if (!data || data.length === 0) {
                    taobao.core.call("taobao.itemcats.get.all", {
                        method: 'taobao.itemcats.get',
                        fields: 'cid,features,parent_cid,name,is_parent,status, sort_order',
                        "parent_cid": "0"
                    }, function (data) {
                        if (data && data.itemcats_get_response && data.itemcats_get_response.item_cats) {
                            async.each(data.itemcats_get_response.item_cats.item_cat, function (item, cb) {
                                var cat = new Cat({
                                    key: "cat_name_" + item.parent_cid + "_" + item.cid,
                                    status: 1,
                                    taobaoInfo: item
                                });

                                cat.save(function (err) {
                                    cb(err);
                                });
                            }, function (err) {
                                return cb(err);
                            });
                        } else {
                            return cb(new Error("fetch cats failed"));
                        }
                    });
                } else {
                    cb(null);
                }
            },

            function (cb) {
                console.log("queryConfirmedCats");
                Category.queryConfirmedCats(function (err, data) {
                    cb(err, data);
                });
            },

            function (data, cb) {
                console.log("setShownCategories");
                that.mem.set("shown_categories", data, function (err) {
                    return cb(err);
                });
            }
        ], function (err) {
            console.log("final");
        });
    })();

    return {
        getCats: function (cb) {
//            Category.queryConfirmedCats(function (err, data) {
//                cb(err, data);
//            });
            return that.mem.get("shown_categories", cb);
        }
    };
}());