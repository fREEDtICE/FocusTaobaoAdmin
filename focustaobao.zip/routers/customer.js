var taobao = require("taobao"),
    path = require("path"),
    swig = require("swig"),
    async = require("async"),
    validator = require('validator'),
    catMag = require("../models/CategoryManager"),
    mem = require("../datas/MemManager").getMem("taopaoapi"),
    httphelper = require("../utils/HttpHelper");


var OrderExports = require("../models/Order"),
    Order = OrderExports.model,
    OrderItem = OrderExports.itemModel;

module.exports = function (app) {
    var shoppingCookieTime = 60 * 60 * 24 * 1000;
    app.post("/cus/shoppingcart/add/:cid/:pid", function (req, res, next) {
        var cid = validator.toInt(req.params.cid),
            pid = validator.toInt(req.params.pid),
            price = validator.toFloat(req.body.price),
            name = validator.escape(validator.trim(req.body.name)),
            img = validator.toString(req.body.img_url);
        if (!validator.isNumeric(cid) || !validator.isNumeric(pid) || !validator.isFloat(price) || !validator.isURL(img) || !name) {
            return httphelper.errorResponse(res);
        }

        var order = req.session.shoppingcart;
        if (!order) {
            order = {};
            req.session.shoppingcart = order;
        }

        if (order[pid]) {
            order[pid].quality = order[pid].quality + 1;
        } else {
            order[pid] = {
                cid: cid,
                productId: pid,
                price: price,
                quality: 1,
                img_url: img,
                name: name
            };
        }


        res.cookie('shoppingcart', JSON.stringify(order), { maxAge: Date.now() + shoppingCookieTime, signed: true });

        return httphelper.JSONResponse(res, {status: "success"});
    });
};
