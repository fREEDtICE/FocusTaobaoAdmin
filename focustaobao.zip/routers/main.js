var taobao = require("./taobao"),
    customer = require("./customer"),
    admin = require("./admin");


module.exports = function (app) {
    taobao(app);
    customer(app);
    admin(app);
}